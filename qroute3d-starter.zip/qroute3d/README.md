# QRoute3D

**Operationally-Grounded XY-Mixer QAOA for 3D UAV Path Planning**

QRoute3D is an open-source benchmark suite investigating whether topology-preserving
XY-mixer QAOA produces higher *operational* feasibility rates than penalty-based
standard QAOA for 3D UAV path planning under real IBM Quantum hardware noise — and
whether that advantage erodes with increasing circuit depth.

Every prior quantum routing paper measures solution quality in abstract graph terms
(path length, approximation ratio, Hamming-weight preservation). This project adds a
metric no one else uses: **operational feasibility**, evaluated against
expert-validated UAV constraints (clearance, tilt angle, climb/descent rate, energy
cost) rather than abstract graph validity alone. The gap between the two — a bitstring
that preserves Hamming weight but fails real-world path validity — is the project's
central novelty claim: the **feasibility gap**.

Research context: SRT IV (Science Research and Technology IV) capstone, Aberdeen High
School Science and Mathematics Academy. Not an ISEF-track project.

## Status

Actively in development. Circuit build and encoding proof are in progress — see
[`docs/encoding.md`](docs/encoding.md) for the current state of the k-hot path
encoding and its post-selection rule.

## Repository structure

| Directory | Contents |
|---|---|
| `environments/` | Dense Obstacle and Narrow Passage instance generators |
| `constraints/` | Operational constraint parameters — expert-sourced values clearly separated from self-derived placeholders |
| `circuits/` | XY-mixer, standard X-mixer, and warm-start QAOA circuit builders (Qiskit) |
| `feasibility/` | Operational feasibility checker — the classical post-selection predicate applied to measured bitstrings |
| `benchmarks/` | Classical baselines: A*, Dijkstra, RRT*, PRM (Tier 2); SA, GA, ACO, MOEA/D (Tier 1) |
| `analysis/` | Feasibility rate, feasibility gap, ZNE pipeline, statistical tests |
| `data/` | IBM hardware results and calibration data (raw result files are git-ignored — see `data/README.md`) |
| `notebooks/` | Reproduction notebooks for every reported figure |
| `docs/` | Design notes, including the encoding write-up |
| `tests/` | Sanity tests for circuit correctness and predicate logic |

## Install

```bash
git clone https://github.com/YOUR-USERNAME/qroute3d.git
cd qroute3d
pip install -r requirements.txt
```

## Why this matters

Expert-validated environments and an operational feasibility metric mean this is the
first quantum routing benchmark suite grounded in professional UAV operational
practice rather than synthetic parameters. Constraint values are sourced from
professional UAV program management practice (Pepco Holdings) and are documented as
**representative example assumptions**, not fixed engineering requirements — see
`constraints/README.md` for the full provenance table.

## Citation

See [`CITATION.cff`](CITATION.cff).

## License

MIT — see [`LICENSE`](LICENSE).
