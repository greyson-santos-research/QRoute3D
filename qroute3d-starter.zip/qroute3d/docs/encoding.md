# Encoding write-up: k-hot path encoding

Full write-up maintained in the project's private research drive; this is the
public summary.

## The core problem

Hamming-weight preservation (guaranteed by the XY-mixer) is necessary but not
sufficient for path validity. A bitstring can have the correct weight k and
still encode a disconnected, invalid set of voxels.

## Worked counterexample (ring graph)

An 8-voxel ring around a single obstacle. Valid path `{0,1,2,3,4}` (bitstring
`11111000`), start=0, goal=4. A single legal XY-mixer swap on edge (4,7)
produces `11110001` (`{0,1,2,3,7}`) -- Hamming weight is preserved, but the
goal voxel drops out and voxel 7 is left disconnected. See
`encoding_ring_example.py` in this directory.

## Worked "good" example (diamond graph)

A diamond sub-graph where start connects to two parallel voxels (a1, b1),
both connecting onward to goal. A swap on edge (a1,b1) reroutes a valid path
through the parallel voxel while staying fully valid -- the mixer legally
exploring an alternative route, not breaking anything.

**Structural takeaway:** whether a swap is safe or destructive depends on
local topology around the swapped edge -- a shared detour on both sides
keeps it safe, a swap at the fixed boundary of the occupied path (touching
start or goal directly) breaks it.

## Post-selection rule

See `feasibility/checker.py` -- `is_valid_path()` implements the full
predicate: weight check, start/goal membership, connectivity, and
simple-path degree constraints.

## Open item

The candidate-selection mapping -- how n candidate voxels are systematically
chosen from the full voxel graph |V| -- is not yet resolved. Worked examples
above use small hand-picked graphs to prove the reasoning.
