EDGES = [(0,1),(1,2),(2,3),(3,4),(4,7),(7,6),(6,5),(5,0)]
ADJ = {i: set() for i in range(8)}
for a, b in EDGES:
    ADJ[a].add(b)
    ADJ[b].add(a)

START, GOAL = 0, 4
K = 5

def occupied(bitstring):
    return {i for i, b in enumerate(bitstring) if b == '1'}

def is_valid_path(bitstring):
    S = occupied(bitstring)
    if len(S) != K:
        return False, "wrong weight"
    if START not in S or GOAL not in S:
        return False, "missing start or goal"
    induced = {v: (ADJ[v] & S) for v in S}
    degrees = {v: len(neighbors) for v, neighbors in induced.items()}
    seen = {START}
    frontier = [START]
    while frontier:
        cur = frontier.pop()
        for nb in induced[cur]:
            if nb not in seen:
                seen.add(nb)
                frontier.append(nb)
    if seen != S:
        return False, f"disconnected: reached {sorted(seen)}, occupied {sorted(S)}"
    for v in S:
        expected = 1 if v in (START, GOAL) else 2
        if degrees[v] != expected:
            return False, f"bad degree at v{v}: got {degrees[v]}, expected {expected}"
    return True, "valid simple path"

def xy_swap(bitstring, i, j):
    bits = list(bitstring)
    if bits[i] != bits[j]:
        bits[i], bits[j] = bits[j], bits[i]
    return ''.join(bits)

start_state = ['0'] * 8
for v in [0,1,2,3,4]:
    start_state[v] = '1'
start_state = ''.join(start_state)

print(f"Start state (clockwise path):  {start_state}  -> occupied {sorted(occupied(start_state))}")
ok, reason = is_valid_path(start_state)
print(f"  valid path? {ok}  ({reason})\n")

swapped = xy_swap(start_state, 4, 7)
print(f"After XY-swap on edge (4,7):   {swapped}  -> occupied {sorted(occupied(swapped))}")
ok, reason = is_valid_path(swapped)
print(f"  valid path? {ok}  ({reason})")
print(f"  Hamming weight preserved? {swapped.count('1') == start_state.count('1')}")
