"""
XY-mixer layer builder.

H_XY on edge (i,j) = X_i X_j + Y_i Y_j
Mixer unitary: exp(-i * beta * (X_i X_j + Y_i Y_j)) = RXX(2*beta) * RYY(2*beta)

Preserves Hamming weight by construction -- see tests/test_xy_mixer.py for
the numerical verification.
"""
from qiskit import QuantumCircuit


def xy_mixer_layer(beta, edges, n_qubits):
    """One XY-mixer layer applied across the given edge set."""
    qc = QuantumCircuit(n_qubits, name=f"XYmixer(beta={beta:.3f})")
    for (i, j) in edges:
        qc.rxx(2 * beta, i, j)
        qc.ryy(2 * beta, i, j)
    return qc
