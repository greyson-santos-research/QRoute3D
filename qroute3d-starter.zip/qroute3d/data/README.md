# Data

Raw IBM hardware result files and calibration snapshots are git-ignored (see
`.gitignore`) to keep the repo lightweight and avoid committing anything
tied to an IBM Quantum account. This file documents the expected schema so
results are reproducible from the notebooks in `notebooks/` without the raw
files being tracked in git.

## Expected structure (once populated)

- `data/raw/<environment>_<variant>_p<depth>_n<qubits>.json` -- per-shot
  results plus IBM backend calibration snapshot at execution time
  (T1, T2, gate error rates via `backend.properties()`).
