"""
Operational feasibility checker.

Applies the classical post-selection predicate to a measured bitstring:
Hamming weight preservation is necessary but not sufficient for path
validity -- see docs/encoding.md for the worked counterexample this
predicate is built to catch.
"""

def occupied_voxels(bitstring):
    """Return the set of qubit indices that are '1' in the bitstring."""
    return {i for i, b in enumerate(bitstring) if b == '1'}


def is_valid_path(bitstring, adjacency, start, goal, k):
    """
    Classical post-selection predicate.

    Parameters
    ----------
    bitstring : str
        Measured bitstring, one bit per candidate voxel qubit.
    adjacency : dict[int, set[int]]
        Voxel adjacency graph over candidate qubit indices (face-adjacency
        in the real voxel grid, not just mixer-graph edges).
    start, goal : int
        Qubit indices of the start and goal voxels.
    k : int
        Expected path length (number of waypoints).

    Returns
    -------
    (bool, str) : whether the bitstring is a valid operational path, and a
    short reason string for diagnostics.
    """
    S = occupied_voxels(bitstring)

    if len(S) != k:
        return False, "wrong weight"
    if start not in S or goal not in S:
        return False, "missing start or goal"

    induced = {v: (adjacency.get(v, set()) & S) for v in S}
    seen = {start}
    stack = [start]
    while stack:
        cur = stack.pop()
        for nb in induced[cur]:
            if nb not in seen:
                seen.add(nb)
                stack.append(nb)
    if seen != S:
        return False, f"disconnected: reached {sorted(seen)}, occupied {sorted(S)}"

    for v in S:
        expected_degree = 1 if v in (start, goal) else 2
        if len(induced[v]) != expected_degree:
            return False, f"bad degree at qubit {v}: expected {expected_degree}"

    return True, "valid simple path"
