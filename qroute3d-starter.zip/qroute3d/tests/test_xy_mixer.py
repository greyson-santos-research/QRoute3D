import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
from circuits.xy_mixer import xy_mixer_layer

N_QUBITS = 4
EDGES = [(0, 1), (1, 2), (2, 3)]


def hamming_weight(bitstring):
    return bitstring.count("1")


def test_xy_mixer_preserves_hamming_weight():
    for start_int in range(2 ** N_QUBITS):
        start_bits = format(start_int, f"0{N_QUBITS}b")
        start_weight = hamming_weight(start_bits)

        qc = QuantumCircuit(N_QUBITS)
        for q, bit in enumerate(reversed(start_bits)):
            if bit == "1":
                qc.x(q)
        qc.compose(xy_mixer_layer(0.7, EDGES, N_QUBITS), inplace=True)

        sv = Statevector.from_instruction(qc)
        for bits, p in sv.probabilities_dict().items():
            if p > 1e-9:
                assert hamming_weight(bits) == start_weight, (
                    f"leakage: {start_bits} -> {bits}"
                )


def test_xy_mixer_is_nontrivial():
    """Confirm the mixer actually moves amplitude within the weight subspace."""
    qc = QuantumCircuit(N_QUBITS)
    qc.x(0)
    qc.x(1)
    qc.compose(xy_mixer_layer(0.7, EDGES, N_QUBITS), inplace=True)
    sv = Statevector.from_instruction(qc)
    probs = sv.probabilities_dict()
    nonzero_states = [b for b, p in probs.items() if p > 1e-9]
    assert len(nonzero_states) > 1, "mixer produced no spread -- check angle/edges"
