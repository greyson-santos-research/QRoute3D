import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from feasibility.checker import is_valid_path

# Ring graph around a single obstacle (docs/encoding.md worked example)
RING_ADJ = {
    0: {1, 5}, 1: {0, 2}, 2: {1, 3}, 3: {2, 4},
    4: {3, 7}, 7: {4, 6}, 6: {7, 5}, 5: {6, 0},
}
RING_START, RING_GOAL, RING_K = 0, 4, 5


def test_valid_ring_path():
    ok, _ = is_valid_path("11111000", RING_ADJ, RING_START, RING_GOAL, RING_K)
    assert ok


def test_counterexample_is_caught():
    """Weight-preserving swap that breaks the path -- must be rejected."""
    ok, reason = is_valid_path("11110001", RING_ADJ, RING_START, RING_GOAL, RING_K)
    assert not ok
    assert "missing start or goal" in reason


# Diamond graph -- a legal reroute that must be accepted
DIAMOND_ADJ = {
    'a0': {'a1', 'b1'}, 'a1': {'a0', 'a2'},
    'b1': {'a0', 'a2'}, 'a2': {'a1', 'b1', 'a3'}, 'a3': {'a2'},
}


def test_diamond_reroute_is_valid():
    S = {'a0', 'b1', 'a2', 'a3'}
    bitstring_map = {n: ('1' if n in S else '0') for n in DIAMOND_ADJ}
    # is_valid_path expects index-based bitstrings; adapt inline for this example
    order = ['a0', 'a1', 'b1', 'a2', 'a3']
    bits = ''.join(bitstring_map[n] for n in order)
    idx_adj = {i: {order.index(nb) for nb in DIAMOND_ADJ[n]} for i, n in enumerate(order)}
    ok, _ = is_valid_path(bits, idx_adj, order.index('a0'), order.index('a3'), 4)
    assert ok
