# Constraints

Operational constraint parameters used to build the Dense Obstacle and
Narrow Passage environments. Values are sourced from professional UAV
program management practice (Pepco Holdings) via the project's research
mentor, and are documented as representative example assumptions, not
fixed engineering requirements.

Each constraint in this directory's code is tagged as either:
- `expert_sourced` -- direct mentor-provided value
- `self_derived` -- placeholder pending mentor validation, never attributed
  to the mentor or Pepco Holdings

See the project's master research plan for the full provenance table.
